php-hello-world/
├── helloworld.php    # Main PHP file containing HTML and PHP code
└── README.md         # Project documentation and guide